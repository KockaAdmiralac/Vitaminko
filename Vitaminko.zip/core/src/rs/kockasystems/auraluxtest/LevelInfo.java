package rs.kockasystems.auraluxtest;

public class LevelInfo 
{
	public String name;
	public String title;
	public String description;
}
