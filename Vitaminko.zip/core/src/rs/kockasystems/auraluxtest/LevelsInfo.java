package rs.kockasystems.auraluxtest;

import com.badlogic.gdx.utils.Array;

public class LevelsInfo
{
	public int nLevels;
	public Array<LevelInfo> levels;
}
