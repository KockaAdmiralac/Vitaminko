package rs.kockasystems.auraluxtest;

public class BarrackData
{
	public float x, y;
	public String team;
}
