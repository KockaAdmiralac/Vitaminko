package rs.kockasystems.auraluxtest;

import com.badlogic.gdx.utils.Array;

public class LevelData
{
	public Array<BarrackData> barracks;
}